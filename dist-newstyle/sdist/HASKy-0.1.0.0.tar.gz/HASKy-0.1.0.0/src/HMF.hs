{-# LANGUAGE NamedFieldPuns #-}
{-# LANGUAGE OverloadedStrings #-}

module HMF where

{-
Module      : HASKy.HMF
Description : Halo Mass Function
Copyright   : (c) Oleksii Sokoliuk, 20256
License     : MIT
Maintainer  : oleksii.sokoliuk@mao.kiev.ua
Stability   : experimental
Portability : portable

This module defines a bunch of routines that in the end
yield a Halo Mass Function for a given cosmology (i.e., values of
Hubble parameter H0, Omega_m0, Omega_b0)
-}

import Cosmology
import qualified Data.Map as M
import qualified Data.Map.Strict as M'
import Data.Maybe
import qualified Data.Text as T
import qualified Data.Vector as V
import Helper
import Math.GaussianQuadratureIntegration
import Numeric.Tools.Differentiation
import Numeric.Tools.Integration
import qualified Safe
import System.IO

-- Define an HMF datatype, consisting of five possible choices
data HMFKind
  = Tinker
  | ST
  | Angulo
  | Jenkins
  | Warren
  deriving (Eq, Show)

-- Similarly, define the options for the window function
data WKind
  = TopHat
  | Smooth
  | Sharp
  deriving (Eq, Show)

-- Some simple types added for convenience
type Wavenumber = Double

type Mhalo = Double

type Rhalo = Double

type PowerSpectrum = Redshift -> Wavenumber -> Double

-- | Define a radius for the uniform density sphere in terms of it's mass
rh :: ReferenceCosmology -> WKind -> Mhalo -> Rhalo
rh cosmology wKind mh =
  let (h0, om0, ob0, _, gn, _, _, _, _) = unpackCosmology cosmology
      rho_mean = 3 * h0 ** 2 * om0 / (8 * pi * gn)
      c_smooth = 3.3
      c_sharp = 2.5
   in case wKind of
        TopHat -> (3 * mh / (4 * pi * rho_mean)) ** (1 / 3)
        Smooth -> (3 * mh / (4 * pi * rho_mean * c_smooth ** 3)) ** (1 / 3)
        Sharp -> (3 * mh / (4 * pi * rho_mean * c_sharp ** 3)) ** (1 / 3)

-- | Produces a matter power spectrum at the linear level
-- To be imported from CAMB
powerSpectrum :: FilePath -> IO ([Double], [Double])
powerSpectrum filepath =
  do
    content <- readFile filepath
    let linesOfFile = lines content
        parsedLines = map parseLine linesOfFile
        (xValues, yValues) = unzip parsedLines
    return (xValues, yValues)
  where
    parseLine line =
      case words line of
        [xVal, yVal] -> (read xVal, read yVal)
        _ -> error $ "Invalid entry at line:" ++ line

-- | Window function, used to derive the cosmic variance
-- You have a choice of two different ones, namely:
--    * Top-Hat
--    * Smooth-k
--    * Sharp-k
windowFunction :: ReferenceCosmology -> WKind -> Wavenumber -> Mhalo -> Double
windowFunction cosmology wKind k mh =
  let r = rh cosmology wKind mh
      kr = k * r
      beta = 4.8
   in case wKind of
        TopHat -> 3 * (sin (kr) - kr * cos (kr)) / (kr) ** 3
        Smooth -> (1 + kr ** beta) ** (-1)
        Sharp -> heaviside (1 - kr)

-- | Cosmic variance squared, usually referred to as sigma^2(R,z)
-- Derived by integrating a matter power spectrum and a window function
cosmicVarianceSq :: ReferenceCosmology -> PowerSpectrum -> Mhalo -> Redshift -> WKind -> Double
cosmicVarianceSq cosmology@MkCosmology {prec} pk mh z wKind =
  let integrand k =
        (k ** 2 / (2 * pi ** 2))
          * (pk z k)
          * (windowFunction cosmology wKind k mh) ** 2
      integrator = makeIntegrator prec

      result = integrator integrand 1e-3 1e3
   in result

-- | First-crossing distribution, crucial for the derivation of a
-- Halo Mass Function afterwards, again you have a choice of five:
--    * Sheth-Tormen
--    * Tinker
--    * Angulo
--    * Jenkins
--    * Warren
-- We are planning to add more options in the near future
firstCrossing :: ReferenceCosmology -> PowerSpectrum -> HMFKind -> WKind -> Mhalo -> Redshift -> Double
firstCrossing cosmology@MkCosmology {h0, om0, ob0} pk hKind wKind mh z =
  let sigma = sqrt $ cosmicVarianceSq cosmology pk mh z wKind
      ez2 = om0 * (1 + z) ** 3 + (1 - om0)

      -- Critical linear overdensity threshold with
      -- redshift corrections from [Kitayama et al. 1996]
      delta_c :: Redshift -> Double
      delta_c z = 1.686 * ((om0 * (1 + z) ** 3) / ez2) ** 0.0055
      nu = delta_c z / sigma

      a_T', a_ST', a_ST, p, a_T, b_T, c_T, a_Ang, b_Ang, c_Ang, a_Jen, b_Jen, a_War, b_War, c_War :: Double
      (a_T', a_ST', a_ST, p, a_T, b_T, c_T, a_Ang, b_Ang, c_Ang, a_Jen, b_Jen, a_War, b_War, c_War) =
        (0.186, 0.3222, 0.707, 0.3, 1.47, 2.57, 1.19, 0.201, 2.08, -1.172, 0.315, 0.61, 0.7234, 0.2538, 1.1982)
   in case hKind of
        Tinker -> a_T' * ((sigma / b_T) ** (-a_T) + 1) * exp (-c_T / sigma ** 2)
        ST -> a_ST' * sqrt (2 * a_ST / pi) * nu * (1 + (a_ST * nu ** 2) ** (-p)) * exp (-a_ST * nu ** 2 / 2)
        Angulo -> a_Ang * (b_Ang / sigma + 1) ** 1.7 * exp (c_Ang / sigma ** 2)
        Jenkins -> a_Jen * exp (-abs (log (sigma ** (-1)) + b_Jen) ** 3.8)
        Warren -> a_War * (sigma ** (-1.625) + b_War) * exp (-c_War / sigma ** 2)

-- | The Halo Mass Function (HMF) itself, uses most of the functions
-- defined within this module and a differentiation library
{-# INLINE haloMassFunction #-}
haloMassFunction :: ReferenceCosmology -> PowerSpectrum -> HMFKind -> WKind -> Mhalo -> Redshift -> Double
haloMassFunction cosmology@MkCosmology {h0, om0, ob0, gn} pk hKind wKind mh z =
  let rho_mean = 3 * h0 ** 2 * om0 / (8 * pi * gn)

      sigma = \mh -> cosmicVarianceSq cosmology pk mh z wKind
      first_crossing = \mh -> firstCrossing cosmology pk hKind wKind mh z

      diff_func mh = log . sqrt $ sigma mh
      dsdm = diffRes $ diffRichardson diff_func (mh * 1e-6) mh
      fdsdlogm = dsdm * first_crossing mh
   in -rho_mean * fdsdlogm

-- | Escape velocity squared of a star from a halo of mass M and radius R at the redshift z,
-- in the units of [km^2 s^-2], taken from the [Tan et al. 2018]
escapeVelocitySq :: ReferenceCosmology -> PowerSpectrum -> HMFKind -> WKind -> Mhalo -> Redshift -> Double
escapeVelocitySq cosmology@MkCosmology {h0, om0, ob0, gn, prec} pk hKind wKind mh_min z =
  let first_crossing =
        (\mh -> firstCrossing cosmology pk hKind wKind mh z)

      integrand_1 mh =
        mh * (2 * gn * mh / rh cosmology wKind mh) * first_crossing mh
      integrand_2 mh =
        mh * first_crossing mh
      integrator = makeIntegrator prec

      result =
        (integrator integrand_1 mh_min 1e17)
          / (integrator integrand_2 mh_min 1e17)
   in result
