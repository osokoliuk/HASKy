{-# LANGUAGE NamedFieldPuns #-}
{-# LANGUAGE OverloadedStrings #-}
{-# LANGUAGE RecordWildCards #-}

module Cosmology where

{-
Module      : HASKy.Cosmology
Description : Cosmology module
Copyright   : (c) Oleksii Sokoliuk, 2026
License     : MIT
Maintainer  : oleksii.sokoliuk@mao.kiev.ua
Stability   : experimental
Portability : portable

A module that defines reference cosmology. Pretty much used by
every other module in this library.
-}

import Control.Parallel.Strategies
import Helper
import Math.GaussianQuadratureIntegration
import StarFormation
import System.Environment
import Text.Read (readMaybe)

-- Define a cosmological model datatype, which currently covers:
--  * CDM     -> Cold Dark Matter (Standard LCDM)
--  * ULDM    -> UltraLight Dark Matter
data CosmologicalModel
  = CDM
  | ULDM {axionMass :: Double}
  deriving (Eq, Show, Read)

-- Define a cosmology datatypes, which includes the following:
--    * h0    -> Hubble parameter in [km s^-1 Mpc^-1]
--    * om0   -> mass fraction of baryons + CDM
--    * ob0   -> analoguously, mass fraction of baryons only
--    * tcmb0 -> temperature of the CMB at the current time in [K]
--    * gn    -> Newton's gravitational constant, in [km^2 Mpc Msun^-1 s^-2]
--    * as    -> 1e9 * amplitude of the primordial scalar power spectrum
--    * ns    -> spectral index of the primordial scalar power spectrum
data ReferenceCosmology
  = MkCosmology
  { h0 :: Double,
    om0 :: Double,
    ob0 :: Double,
    tcmb0 :: Double,
    gn :: Double,
    as :: Double,
    ns :: Double,
    prec :: Precision,
    model :: CosmologicalModel
  }
  deriving (Eq, Show)

type Redshift = Double

type CosmicTime = Double

-- | Unpack the values in the cosmology_record into variables
unpackCosmology :: ReferenceCosmology -> (Double, Double, Double, Double, Double, Double, Double, Precision, CosmologicalModel)
unpackCosmology cosmology =
  (,,,,,,,,) <$> h0 <*> om0 <*> ob0 <*> tcmb0 <*> gn <*> as <*> ns <*> prec <*> model $ cosmology

-- | Example Planck 2018 cosmology
planck18 :: ReferenceCosmology
planck18 =
  MkCosmology
    { h0 = 67.66,
      om0 = (0.02242 / (h0 planck18 / 100) ** 2 + 0.11933 / (h0 planck18 / 100) ** 2),
      ob0 = 0.02242 / (h0 planck18 / 100) ** 2,
      tcmb0 = 2.7255,
      gn = 4.301 * 10 ** (-9),
      as = 2.105,
      ns = 0.9665,
      prec = P128,
      model = CDM
    }

-- | Initialise cosmological model from the args, to be provided from the CLI
initialiseCosmology :: [String] -> Maybe ReferenceCosmology
initialiseCosmology [h0S, om0S, ob0S, tcmb0S, gnS, asS, nsS, precS, modelS] =
  do
    let h0 = read h0S
        om0 = read om0S
        ob0 = read ob0S
        tcmb0 = read tcmb0S
        gn = read gnS
        as = read asS
        ns = read nsS
        prec = read precS
        model = read modelS

    pure $ MkCosmology {h0, om0, ob0, tcmb0, gn, as, ns, prec, model}
initialiseCosmology _ = Nothing

-- | Fiducial Lambda CDM Hubble parameter, in the units of [km s^-1 Mpc^-1]
hubbleParameter :: ReferenceCosmology -> Redshift -> Double
hubbleParameter cosmology@MkCosmology {h0, om0, ob0} z =
  h0 * sqrt (om0 * (1 + z) ** 3 + 1 - om0)

-- | dt/dz, will be used as an integrand to derive cosmic time
dtdz :: ReferenceCosmology -> Redshift -> Double
dtdz cosmology@MkCosmology {h0, om0, ob0} z =
  let km_Mpc = 3.24 * 1e-20
      s_Gyr = 3.15 * 1e16
   in (km_Mpc * s_Gyr * (1 + z) * hubbleParameter cosmology z) ** (-1)

-- | Define cosmic time t(z) in the units of [Gyr]
cosmicTime :: ReferenceCosmology -> Redshift -> CosmicTime
cosmicTime cosmology z =
  let IGMParams {..} = defaultIGMParams
      PhysicalConstants {..} = phys
   in nIntegrate256 (dtdz cosmology) z zMax

-- | Make some general definitions for redshift and related cosmic time lookup tables
-- and interpolation functions
zs :: [Double]
zs =
  let IGMParams {..} = defaultIGMParams
      PhysicalConstants {..} = phys
   in [zMax, zMax - dz .. zMin]

ts :: ReferenceCosmology -> [Double]
ts cosmology = parMap rpar (\z -> cosmicTime cosmology z) zs

interpT :: ReferenceCosmology -> Double -> Double
interpT cosmology =
  makeInterp zs $ ts cosmology

interpZ :: ReferenceCosmology -> Double -> Double
interpZ cosmology =
  makeInterp (ts cosmology) zs
