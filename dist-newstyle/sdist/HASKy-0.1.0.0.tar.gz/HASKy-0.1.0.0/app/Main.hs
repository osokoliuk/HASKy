module Main where

-- import Cosmology
import HMF ()
import Helper ()
import IGM ()
import Lookup ()
import SMF ()

-- import SMF

args :: [Double]
args = []

main :: IO ()
main = main_HMF
